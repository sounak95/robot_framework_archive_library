[![Build Status](https://travis-ci.org/bulkan/robotframework-archivelibrary.png?branch=master)](https://travis-ci.org/bulkan/robotframework-archivelibrary)
[![PyPi downloads](https://pypip.in/d/robotframework-archivelibrary/badge.png)](https://crate.io/packages/robotframework-archivelibrary/)

A keyword library for Robot Framework


Installation
============

To get started you can install via;

```pip install robotframework-archivelibrary```


Keyword documentation is available at [http://bulkan.github.io/robotframework-archivelibrary](http://bulkan.github.io/robotframework-archivelibrary)


See the example testcase for usage
